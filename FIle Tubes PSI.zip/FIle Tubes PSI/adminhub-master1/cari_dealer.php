<?php
include 'db.php';
session_start();

if( !isset($_SESSION["login"])){
	header("location: login.php");
	exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">

	<title>Dashboard</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<!-- <i class='bx bxs-image'> -->
				<img src="logo_honda.png">
			<!-- </i> -->
			<span class="text">HONDA</span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="dashboard.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
            <li>
				<a href="informasi.php">
					<i class='bx bxs-info-circle' ></i>
					<span class="text">Informasi Harga Kendaraan</span>
				</a>
			</li>
			<li>
				<a href="spesifikasi_motor.php">
					<i class='bx bxs-donate-blood' ></i>
					<span class="text">Spesifikasi Motor</span>
				</a>
			</li>
			<li>
				<a href="bandingkan_harga.php">
					<i class='bx bx-search-alt-2' ></i>
					<span class="text">Bandingkan Harga Motor</span>
				</a>
			</li>
			<li>
				<a href="chart.php">
					<i class='bx bx-chart' ></i>
					<span class="text">Chart</span>
				</a>
			</li>
            <li class="active">
				<a href="cari_dealer.php">
					<i class='bx bxs-home-circle' ></i>
					<span class="text">Cari Dealer</span>
				</a>
			</li>
		</ul>

		<ul class="side-menu">
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="profile">
				<img src="img/people.png">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
		<div class="card">
				<div class="card-head">
					<h2 class="mx-auto">Cari Dealer</h2>
				</div>
				

<div class="card-body">

<script>
function submitForm() {
  document.getElementById("formFilter").submit();
}
</script>

<form id="formFilter" method="post" action="">       
    <select name="kendaraan" id="optionKendaraan" class="form-select" style="width: 400px;" onchange="submitForm()">
        <option value="" <?php echo (isset($_POST['kendaraan']) && $_POST['kendaraan'] === '') ? 'selected' : ''; ?>>Pilih Kota</option>
        <option value="Yogyakarta" <?php echo (isset($_POST['kendaraan']) && $_POST['kendaraan'] === 'Yogyakarta') ? 'selected' : ''; ?>>Yogyakarta</option>
        <option value="Semarang" <?php echo (isset($_POST['kendaraan']) && $_POST['kendaraan'] === 'Semarang') ? 'selected' : ''; ?>>Semarang</option>
        <option value="Surabaya" <?php echo (isset($_POST['kendaraan']) && $_POST['kendaraan'] === 'Surabaya') ? 'selected' : ''; ?>>Surabaya</option>
    </select>
</form>


    <div class="row dealer-container">
        <?php
        // Periksa apakah data 'kendaraan' telah dikirim melalui metode POST
        if (isset($_POST['kendaraan'])) {
            // Query SQL untuk mengambil data dealer berdasarkan kota yang dipilih
            $sql = "SELECT * FROM dealer WHERE kota = '" . $_POST['kendaraan'] . "'";
            $result = $conn->query($sql);

            // Periksa apakah ada hasil data
            if ($result->num_rows > 0) {
                // Looping melalui hasil data
                while ($row = $result->fetch_assoc()) {
                    $dealer_nama = $row["dealer_nama"];
                    $alamat = $row["alamat"];
                    $kota = $row["kota"];
                    $telp = $row["telp"];

                    // Tampilkan data dealer dalam format yang diinginkan
                    echo '<div class="box">';
                    echo '<div class="dealer-item">';
                    echo '<div class="dealer-title">';
                    echo '<div class="dealer-text">' . $dealer_nama . '</div>';
                    echo '<div class="title-icon"><i class="bx bxl-telegram"></i></div>';
                    echo '</div>';
                    echo '<div class="dealer-address">' . $alamat . '</div>';
                    echo '<div class="dealer-logo">';
                    echo '<img src="./logo_honda.png" width="1rem" alt="">' . $kota;
                    echo '</div>';
                    echo '<div class="dealer-contact">';
                    echo '<div class="phone">' . $telp . '</div>';
                    echo '<div class="call"><i class="bx bxs-phone"></i></div>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                // Tampilkan pesan jika tidak ada data dealer yang sesuai
                echo '<div class="box">';
                echo '<div class="dealer-item">';
                echo 'Tidak ada dealer yang tersedia';
                echo '</div>';
                echo '</div>';
            }
        } else {
            // Tampilkan pesan jika data 'kendaraan' belum dikirim
            echo '<div class="box">';
            echo '<div class="dealer-item">';
            echo 'Pilih kota untuk melihat dealer';
            echo '</div>';
            echo '</div>';
        }
        ?>
    </div>
</div>


			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>
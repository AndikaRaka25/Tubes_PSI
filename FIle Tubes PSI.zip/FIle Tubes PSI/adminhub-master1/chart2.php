<?php
include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bar Chart Penjualan Motor</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<canvas id="chartYogyakarta"></canvas>

<?php
// Query untuk mengambil data penjualan
$query = "SELECT MONTH(date) AS month, COUNT(*) AS total FROM penjualan
          INNER JOIN motor ON penjualan.motor_id = motor.motor_id
          WHERE motor.dealer_id IN (1, 2, 3) 
          AND YEAR(date) = YEAR(CURRENT_DATE())
          GROUP BY MONTH(date)";

$result = mysqli_query($conn, $query);

// Inisialisasi array bulan dan jumlah penjualan
$bulan = [];
$jumlahPenjualan = [];

// Memasukkan data ke dalam array bulan dan jumlah penjualan
while ($row = mysqli_fetch_assoc($result)) {
    $bulan[] = date("F", mktime(0, 0, 0, $row['month'], 1));
    $jumlahPenjualan[] = $row['total'];
}
?>

<script>
var ctx = document.getElementById('chartYogyakarta').getContext('2d');
var chart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($bulan); ?>,
        datasets: [{
            label: 'Penjualan',
            data: <?php echo json_encode($jumlahPenjualan); ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true,
                stepSize: 1
            }
        }
    }
});
</script>



<canvas id="chartSemarang"></canvas>

    <?php
    

    // Query untuk mengambil data penjualan
    $query2 = "SELECT MONTH(date) AS month, COUNT(*) AS total FROM penjualan
              INNER JOIN motor ON penjualan.motor_id = motor.motor_id
              WHERE motor.dealer_id = 4 
              AND YEAR(date) = YEAR(CURRENT_DATE())
              GROUP BY MONTH(date)";

    $result = mysqli_query($conn, $query2);

    // Inisialisasi array bulan dan jumlah penjualan
    $bulan = [];
    $jumlahPenjualan = [];

    // Memasukkan data ke dalam array bulan dan jumlah penjualan
    while ($row = mysqli_fetch_assoc($result)) {
        $bulan[] = date("F", mktime(0, 0, 0, $row['month'], 1));
        $jumlahPenjualan[] = $row['total'];
    }
    ?>

    <script>
    var ctx = document.getElementById('chartSemarang').getContext('2d');
    var chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($bulan); ?>,
            datasets: [{
                label: 'Penjualan',
                data: <?php echo json_encode($jumlahPenjualan); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    stepSize: 1
                }
            }
        }
    });
    </script>




<canvas id="chartSurabaya"></canvas>

    <?php
    

    // Query untuk mengambil data penjualan
    $query3 = "SELECT MONTH(date) AS month, COUNT(*) AS total FROM penjualan
              INNER JOIN motor ON penjualan.motor_id = motor.motor_id
              WHERE motor.dealer_id IN (5, 6) 
              AND YEAR(date) = YEAR(CURRENT_DATE())
              GROUP BY MONTH(date)";

    $result = mysqli_query($conn, $query3);

    // Inisialisasi array bulan dan jumlah penjualan
    $bulan = [];
    $jumlahPenjualan = [];

    // Memasukkan data ke dalam array bulan dan jumlah penjualan
    while ($row = mysqli_fetch_assoc($result)) {
        $bulan[] = date("F", mktime(0, 0, 0, $row['month'], 1));
        $jumlahPenjualan[] = $row['total'];
    }
    ?>

    <script>
    var ctx = document.getElementById('chartSurabaya').getContext('2d');
    var chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($bulan); ?>,
            datasets: [{
                label: 'Penjualan',
                data: <?php echo json_encode($jumlahPenjualan); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    stepSize: 1
                }
            }
        }
    });
    </script>

    

</body>
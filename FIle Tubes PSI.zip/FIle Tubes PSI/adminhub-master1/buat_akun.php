<?php
require 'functions.php';
if( isset($_POST["register"]) ) { 

    if( registrasi($_POST) > 0) {
        header('location:login.php');
        
    }else{
        echo mysqli_error($conn);
    }
    }

?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/styleregist.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="wave redd.png">
	<img class="wave2" src="wave reddd.png">

	<div class="container">
        <h3 class="title">Buat Akun</h3><br>

        <!-- <div class="login-content"> -->
			<form action="" method="post">
            <input type="text" placeholder="Username" name="username" id="username" required>
                <input type="password" placeholder="Password" name="password" id="password" required>
                <input type="password" placeholder="Re-enter Password"name="repassword" id="repassword" required>
			
            <div class="terms">
                <input type="checkbox" id="checkbox" required> <label for="checkbox"> Saya setuju dengan syarat & ketentuan yang berlaku</label>
            </div>
            <button type="submit" name="register">Buat</button>
            </form>

            <div class="member">Sudah punya akun?
                <a href="login.php">Klik disini</a>
            </div>
    </div>
			</form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>




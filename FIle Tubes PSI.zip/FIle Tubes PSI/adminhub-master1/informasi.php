<?php
include 'db.php';
session_start();

if( !isset($_SESSION["login"])){
	header("location: login.php");
	exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">

	<title>Dashboard</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<!-- <i class='bx bxs-image'> -->
				<img src="logo_honda.png">
			<!-- </i> -->
			<span class="text">HONDA</span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="dashboard.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li class="active">
				<a href="informasi.php">
					<i class='bx bxs-info-circle' ></i>
					<span class="text">Informasi Harga Kendaraan</span>
				</a>
			</li>
			<li>
				<a href="spesifikasi_motor.php">
					<i class='bx bxs-donate-blood' ></i>
					<span class="text">Spesifikasi Motor</span>
				</a>
			</li>
			<li>
				<a href="bandingkan_harga.php">
					<i class='bx bx-search-alt-2' ></i>
					<span class="text">Bandingkan Harga Motor</span>
				</a>
			</li>
			<li>
				<a href="chart.php">
					<i class='bx bx-chart' ></i>
					<span class="text">Chart</span>
				</a>
			</li>
			<li>
				<a href="chart.php">
					<i class='bx bxs-home-circle' ></i>
					<span class="text">Cari Dealer</span>
				</a>
			</li>
		</ul>

		<ul class="side-menu">
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="profile">
				<img src="img/people.png">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			
		<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Motor-Motor Honda</h3>
						<p>Harga dibawah adalah </p>
				    </div>
					<section class="products" id="products">
		<div class="box-container">

		<?php
// Ambil seluruh data motor dengan motor_nama unik
$sqlMotor = "SELECT DISTINCT motor_nama, foto FROM motor";
$resultMotor = $conn->query($sqlMotor);

if ($resultMotor->num_rows > 0) {
    while ($rowMotor = $resultMotor->fetch_assoc()) {
        $motor_nama = $rowMotor['motor_nama'];
        $foto = $rowMotor['foto'];

        // Ambil harga terendah dan tertinggi dari tabel spesifikasi_motor berdasarkan motor_nama
        $sqlHarga = "SELECT MIN(harga) AS harga_terendah, MAX(harga) AS harga_tertinggi FROM spesifikasi_motor WHERE motor_id IN (SELECT motor_id FROM motor WHERE motor_nama = '$motor_nama')";
        $resultHarga = $conn->query($sqlHarga);

        if ($resultHarga->num_rows > 0) {
            $rowHarga = $resultHarga->fetch_assoc();
            $harga_terendah = $rowHarga['harga_terendah'];
            $harga_tertinggi = $rowHarga['harga_tertinggi'];
        }

        // Tampilkan data motor dalam <div class="box">
        ?>
        <div class="box">
            <div class="content">
                <h3><?php echo $motor_nama; ?></h3>
                <div class="info">
                    <img style="width: 50%;" src="honda/<?php echo $foto; ?>" alt="Foto <?php echo $motor_nama; ?>">
                </div>
                <div class="info">
                    <button type="button">Rp <?php echo $harga_terendah; ?> - Rp <?php echo $harga_tertinggi; ?></button>
                    
                </div>
            </div>
        </div>
        <?php
    }
} else {
    // Tampilkan pesan jika tidak ada data motor yang tersedia
    echo "<p>Tidak ada data motor yang tersedia.</p>";
}
?>





		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>
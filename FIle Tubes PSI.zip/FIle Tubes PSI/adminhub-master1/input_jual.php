<?php

include 'db.php';
// Fungsi untuk menghasilkan datetime acak antara dua datetime
function randomDatetime($startDatetime, $endDatetime) {
    $startTimestamp = strtotime($startDatetime);
    $endTimestamp = strtotime($endDatetime);
    $randomTimestamp = mt_rand($startTimestamp, $endTimestamp);
    return date("Y-m-d H:i:s", $randomTimestamp);
}

// Generate 100 query INSERT
$query = "";
for ($i = 1; $i <= 100; $i++) {
    $motorId = mt_rand(1, 26);
    $startDatetime = "2023-01-01 00:00:00";
    $endDatetime = "2023-08-31 23:59:59";
    $datetime = randomDatetime($startDatetime, $endDatetime);
    $query .= "INSERT INTO penjualan (motor_id, date) VALUES ($motorId, '$datetime');\n";
}

// Jalankan query INSERT
if ($conn->multi_query($query) === TRUE) {
    echo "Data berhasil ditambahkan.";
} else {
    echo "Terjadi kesalahan: " . $conn->error;
}

// Tutup koneksi
$conn->close();
?>

<?php
include 'db.php';
session_start();

if( !isset($_SESSION["login"])){
	header("location: login.php");
	exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

	<title>Dashboard</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<!-- <i class='bx bxs-image'> -->
				<img src="logo_honda.png">
			<!-- </i> -->
			<span class="text">HONDA</span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="dashboard.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
            <li>
				<a href="informasi.php">
					<i class='bx bxs-info-circle' ></i>
					<span class="text">Informasi Harga Kendaraan</span>
				</a>
			</li>
			<li>
				<a href="spesifikasi_motor.php">
					<i class='bx bxs-donate-blood' ></i>
					<span class="text">Spesifikasi Motor</span>
				</a>
			</li>
            <li>
				<a href="bandingkan_harga.php">
					<i class='bx bx-search-alt-2' ></i>
					<span class="text">Bandingkan Harga Motor</span>
				</a>
			</li>
			<li class="active">
				<a href="chart.php">
					<i class='bx bx-chart' ></i>
					<span class="text">Chart</span>
				</a>
			</li>
			 <li>
				<a href="cari_dealer.php">
					<i class='bx bxs-home-circle' ></i>
					<span class="text">Cari Dealer</span>
				</a>
			</li>
		</ul>

		<ul class="side-menu">
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="profile">
				<img src="img/people.png">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="card">
				<h3>GRAFIK PENJUALAN TAHUN INI </h3> <br><br><br>
				<div class="">






<form id="formFilter" method="post" action="">       
    <select name="penjualan" id="optionChart" class="form-select" style="width: 400px;">
        <option value="barChart">Semua</option>
        <option value="chartYogyakarta" >Yogyakarta</option>
        <option value="chartSemarang" >Semarang</option>
        <option value="chartSurabaya" >Surabaya</option>
    </select>
</form>


<!-- CHART -->
<canvas id="barChart"></canvas>
<?php
// Query untuk mengambil data penjualan per bulan
$query = "SELECT MONTH(date) AS month, COUNT(*) AS count FROM penjualan WHERE YEAR(date) = YEAR(CURRENT_DATE()) GROUP BY MONTH(date)";
$result = $conn->query($query);

// Inisialisasi array untuk menyimpan data bulan dan jumlah penjualan
$labels = array();
$data = array();

// Memproses hasil query
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$month = $row["month"];
		$count = $row["count"];

		// Mengubah angka bulan menjadi nama bulan
		$monthName = date("F", mktime(0, 0, 0, $month, 1));

		// Menyimpan data bulan dan jumlah penjualan ke dalam array
		$labels[] = $monthName;
		$data[] = $count;
	}
}

// Tutup koneksi

?>

<script>
	// Mengambil data dari PHP dan mengubahnya menjadi JavaScript array
	var labels = <?php echo json_encode($labels); ?>;
	var data = <?php echo json_encode($data); ?>;

	// Membuat bar chart menggunakan Chart.js
	var ctx = document.getElementById("barChart").getContext("2d");
	var barChart = new Chart(ctx, {
		type: 'bar',
		data: {
			labels: labels,
			datasets: [{
				label: 'Penjualan',
				data: data,
				backgroundColor: 'rgba(75, 192, 192, 0.2)',
				borderColor: 'rgba(75, 192, 192, 1)',
				borderWidth: 1
			}]
		},
		options: {
			scales: {
				y: {
					beginAtZero: true,
					stepSize: 1
				}
			}
		}
	});
</script>
<!-- CHART -->

<canvas id="chartYogyakarta"></canvas>

<?php
// Query untuk mengambil data penjualan
$query = "SELECT MONTH(date) AS month, COUNT(*) AS total FROM penjualan
          INNER JOIN motor ON penjualan.motor_id = motor.motor_id
          WHERE motor.dealer_id IN (1, 2, 3) 
          AND YEAR(date) = YEAR(CURRENT_DATE())
          GROUP BY MONTH(date)";

$result = mysqli_query($conn, $query);

// Inisialisasi array bulan dan jumlah penjualan
$bulan = [];
$jumlahPenjualan = [];

// Memasukkan data ke dalam array bulan dan jumlah penjualan
while ($row = mysqli_fetch_assoc($result)) {
    $bulan[] = date("F", mktime(0, 0, 0, $row['month'], 1));
    $jumlahPenjualan[] = $row['total'];
}
?>

<script>
var ctx = document.getElementById('chartYogyakarta').getContext('2d');
var chart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($bulan); ?>,
        datasets: [{
            label: 'Penjualan',
            data: <?php echo json_encode($jumlahPenjualan); ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true,
                stepSize: 1
            }
        }
    }
});
</script>



<canvas id="chartSemarang"></canvas>

    <?php
    

    // Query untuk mengambil data penjualan
    $query2 = "SELECT MONTH(date) AS month, COUNT(*) AS total FROM penjualan
              INNER JOIN motor ON penjualan.motor_id = motor.motor_id
              WHERE motor.dealer_id = 4 
              AND YEAR(date) = YEAR(CURRENT_DATE())
              GROUP BY MONTH(date)";

    $result = mysqli_query($conn, $query2);

    // Inisialisasi array bulan dan jumlah penjualan
    $bulan = [];
    $jumlahPenjualan = [];

    // Memasukkan data ke dalam array bulan dan jumlah penjualan
    while ($row = mysqli_fetch_assoc($result)) {
        $bulan[] = date("F", mktime(0, 0, 0, $row['month'], 1));
        $jumlahPenjualan[] = $row['total'];
    }
    ?>

    <script>
    var ctx = document.getElementById('chartSemarang').getContext('2d');
    var chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($bulan); ?>,
            datasets: [{
                label: 'Penjualan',
                data: <?php echo json_encode($jumlahPenjualan); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    stepSize: 1
                }
            }
        }
    });
    </script>




<canvas id="chartSurabaya"></canvas>

    <?php
    

    // Query untuk mengambil data penjualan
    $query3 = "SELECT MONTH(date) AS month, COUNT(*) AS total FROM penjualan
              INNER JOIN motor ON penjualan.motor_id = motor.motor_id
              WHERE motor.dealer_id IN (5, 6) 
              AND YEAR(date) = YEAR(CURRENT_DATE())
              GROUP BY MONTH(date)";

    $result = mysqli_query($conn, $query3);

    // Inisialisasi array bulan dan jumlah penjualan
    $bulan = [];
    $jumlahPenjualan = [];

    // Memasukkan data ke dalam array bulan dan jumlah penjualan
    while ($row = mysqli_fetch_assoc($result)) {
        $bulan[] = date("F", mktime(0, 0, 0, $row['month'], 1));
        $jumlahPenjualan[] = $row['total'];
    }
    ?>

    <script>
    var ctx = document.getElementById('chartSurabaya').getContext('2d');
    var chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($bulan); ?>,
            datasets: [{
                label: 'Penjualan',
                data: <?php echo json_encode($jumlahPenjualan); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    stepSize: 1
                }
            }
        }
    });
    </script>
				</div>
			</div>
			
		</main>
		<!-- MAIN -->

		
	</section>
	<!-- CONTENT -->
	
	<script>
document.addEventListener("DOMContentLoaded", function() {
  // Semua canvas di-hide terlebih dahulu
  var canvases = document.getElementsByTagName("canvas");
  for (var i = 0; i < canvases.length; i++) {
    canvases[i].style.display = "none";
  }

  // Tampilkan canvas "barChart" saat halaman pertama kali dimuat
  document.getElementById("barChart").style.display = "block";
  
  document.getElementById("optionChart").addEventListener("change", function() {
    var selectedOption = this.value;
  
    // Semua canvas di-hide terlebih dahulu
    for (var i = 0; i < canvases.length; i++) {
      canvases[i].style.display = "none";
    }
  
    // Tampilkan canvas yang sesuai dengan pilihan yang dipilih
    if (selectedOption === "barChart") {
      document.getElementById("barChart").style.display = "block";
    } else if (selectedOption === "chartYogyakarta") {
      document.getElementById("chartYogyakarta").style.display = "block";
    } else if (selectedOption === "chartSemarang") {
      document.getElementById("chartSemarang").style.display = "block";
    } else if (selectedOption === "chartSurabaya") {
      document.getElementById("chartSurabaya").style.display = "block";
    }
  });
});
</script>


	

	<script src="script.js"></script>
</body>
</html>
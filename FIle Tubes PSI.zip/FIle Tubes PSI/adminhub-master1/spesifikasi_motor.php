<?php
include 'db.php';
session_start();

if( !isset($_SESSION["login"])){
	header("location: login.php");
	exit;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">

	<title>Dashboard</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<!-- <i class='bx bxs-image'> -->
				<img src="logo_honda.png">
			<!-- </i> -->
			<span class="text">HONDA</span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="dashboard.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="informasi.php">
					<i class='bx bxs-info-circle' ></i>
					<span class="text">Informasi Harga Kendaraan</span>
				</a>
			</li>
			<li class="active">
				<a href="spesifikasi_motor.php">
					<i class='bx bxs-donate-blood' ></i>
					<span class="text">Spesifikasi Motor</span>
				</a>
			</li>
			<li>
				<a href="bandingkan_harga.php">
					<i class='bx bx-search-alt-2' ></i>
					<span class="text">Bandingkan Harga Motor</span>
				</a>
			</li>
			<li>
				<a href="chart.php">
					<i class='bx bx-chart' ></i>
					<span class="text">Chart</span>
				</a>
			</li>
			<li>
				<a href="cari_dealer.php">
					<i class='bx bxs-home-circle' ></i>
					<span class="text">Cari Dealer</span>
				</a>
			</li>
		</ul>

		<ul class="side-menu">
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="profile">
				<img src="img/people.png">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
		<div class="card">
				<div class="card-head text-center">
					<h2 class="mx-auto">Spesifikasi Motor</h2>
				</div>
				<div class="card-body">					
    <div class="row spesifikasi-motor">		
	<script>
function submitForm() {
  document.getElementById("formFilter").submit();
}
</script>

	<?php
// Periksa apakah nilai 'kendaraan' sudah dikirimkan melalui POST
if (isset($_POST['kendaraan'])) {
    $filterValue = $_POST['kendaraan'];

    // Lanjutan kode yang ada di bawah ini
    // ...
} else {
    // Set nilai default jika tidak ada data yang dikirimkan
    $filterValue = "";
}

// Buat query SQL untuk mengambil data berdasarkan nilai yang dipilih
$sql = "SELECT spesifikasi_motor.mesin, spesifikasi_motor.rangka, spesifikasi_motor.dimensi, spesifikasi_motor.kapasitas, spesifikasi_motor.kelistrikan
        FROM motor
        INNER JOIN spesifikasi_motor ON motor.motor_id = spesifikasi_motor.motor_id
        WHERE motor.motor_nama LIKE '%" . $filterValue . "%'";
$result = $conn->query($sql);


// Periksa apakah ada hasil data
if ($result->num_rows > 0) {
    // Tampilkan data
    $row = $result->fetch_assoc();
    $mesin = $row["mesin"];
    $rangka = $row["rangka"];
    $dimensi = $row["dimensi"];
    $kapasitas = $row["kapasitas"];
    $kelistrikan = $row["kelistrikan"];
} else {
    // Set nilai default jika tidak ada data yang sesuai
    $mesin = "";
    $rangka = "";
    $dimensi = "";
    $kapasitas = "";
    $kelistrikan = "";
}

?>

<form id="formFilter" method="post" action="">
        <?php
        // Periksa apakah nilai 'kendaraan' sudah dikirimkan melalui POST
        if (isset($_POST['kendaraan'])) {
            $filterValue = $_POST['kendaraan'];
        } else {
            // Set nilai default jika tidak ada data yang dikirimkan
            $filterValue = "";
        }
        ?>
        <select name="kendaraan" id="optionKendaraan" class="form-select" style="width: 400px;" onchange="submitForm()">
            <option value="">Pilih Kendaraan</option>
            <option value="Beat" <?php if ($filterValue == "Beat") echo "selected"; ?>>Beat</option>
            <option value="Vario" <?php if ($filterValue == "Vario") echo "selected"; ?>>Vario</option>
            <option value="Scoopy" <?php if ($filterValue == "Scoopy") echo "selected"; ?>>Scoopy</option>
        </select>
    </form>
    </div>
    <div class="tab-container">
        <div class="tab">
            <button class="tablinks" onclick="switchTab(event, 'Mesin')" id="tab-default">Mesin</button>
            <button class="tablinks" onclick="switchTab(event, 'Rangka')">Rangka & Kaki-Kaki</button>
            <button class="tablinks" onclick="switchTab(event, 'Dimensi')">Dimensi & Berat</button>
            <button class="tablinks" onclick="switchTab(event, 'Kapasitas')">Kapasitas</button>
            <button class="tablinks" onclick="switchTab(event, 'Kelistrikan')">Kelistrikan</button>
        </div>

        <div id="Mesin" class="tabcontent">
			<?php if (!empty($filterValue)) : ?>
				<table class="detail-table">
					<tr>
						<td><?php echo $mesin; ?></td>
					</tr>
				</table>
			<?php else : ?>
				<p>Tidak ada data yang ditampilkan.</p>
			<?php endif; ?>
		</div>


        <div id="Rangka" class="tabcontent">
		<?php if (!empty($filterValue)) : ?>
				<table class="detail-table">
					<tr>
						<td><?php echo $rangka; ?></td>
					</tr>
				</table>
			<?php else : ?>
				<p>Tidak ada data yang ditampilkan.</p>
			<?php endif; ?>
		</div>

        <div id="Dimensi" class="tabcontent">
		<?php if (!empty($filterValue)) : ?>
				<table class="detail-table">
					<tr>
						<td><?php echo $dimensi; ?></td>
					</tr>
				</table>
			<?php else : ?>
				<p>Tidak ada data yang ditampilkan.</p>
			<?php endif; ?>
		</div>

        <div id="Kapasitas" class="tabcontent">
		<?php if (!empty($filterValue)) : ?>
				<table class="detail-table">
					<tr>						
						<td><?php echo $kapasitas; ?></td>
					</tr>					
				</table>
			<?php else : ?>
				<p>Tidak ada data yang ditampilkan.</p>
			<?php endif; ?>
		</div>

        <div id="Kelistrikan" class="tabcontent">
		<?php if (!empty($filterValue)) : ?>
				<table class="detail-table">
					<tr>
						<td><?php echo $kelistrikan; ?></td>
					</tr>
				</table>
			<?php else : ?>
				<p>Tidak ada data yang ditampilkan.</p>
			<?php endif; ?>
		</div>

    </div>
</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
	<script>
		function switchTab(evt, tabName) {
			var i, tabcontent, tablinks;
			tabcontent = document.getElementsByClassName("tabcontent");
			for (i = 0; i < tabcontent.length; i++) {
				tabcontent[i].style.display = "none";
			}
			tablinks = document.getElementsByClassName("tablinks");
			for (i = 0; i < tablinks.length; i++) {
				tablinks[i].className = tablinks[i].className.replace(" active", "");
			}
			document.getElementById(tabName).style.display = "block";
			evt.currentTarget.className += " active";
		}
		document.getElementById("tab-default").click();
	</script>
</body>
</html>
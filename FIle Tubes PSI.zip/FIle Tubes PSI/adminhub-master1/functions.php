<?php
$conn = mysqli_connect("localhost", "root", "", "login_anora");

function registrasi($data){
    global $conn;

    $username = strtolower(stripslashes($data["username"]));
    $password = mysqli_real_escape_string($conn, $data["password"]);
    $repassword = mysqli_real_escape_string($conn, $data["repassword"]);

$result =mysqli_query($conn, "SELECT username FROM users WHERE username = '$username'");

if ( mysqli_fetch_assoc($result)){
    echo"<script>
        alert('username telah dipakai, silahkan ganti username anda!');
       </script>";
    return false;
}

if ($password !== $repassword){
    echo"<script>
        alert('konfirmasi password tidak sesuai!');
       </script>";
       return false;
}


$password = password_hash($password, PASSWORD_DEFAULT);

mysqli_query($conn, "INSERT INTO users VALUES('','$username', '$password')");

return mysqli_affected_rows($conn);

 
}

?>
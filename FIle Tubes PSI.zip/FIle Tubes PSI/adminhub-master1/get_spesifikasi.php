<?php
// Mendapatkan nilai dari elemen select
$kendaraan = $_POST['kendaraan'];

// Query untuk mendapatkan data spesifikasi berdasarkan pilihan kendaraan
$query = "SELECT * FROM spesifikasi_mesin
          INNER JOIN motor ON spesifikasi_mesin.motor_id = motor.motor_id
          WHERE motor.motor_nama LIKE ? 
          ORDER BY spesifikasi_mesin.motor_id ASC
          LIMIT 1";

$stmt = $dbh->prepare($query);
$stmt->execute([$kendaraan]);

// Mendapatkan hasil query
$spesifikasi = $stmt->fetch(PDO::FETCH_ASSOC);

// Mengirimkan respon dalam format JSON
header('Content-Type: application/json');
echo json_encode($spesifikasi);
?>

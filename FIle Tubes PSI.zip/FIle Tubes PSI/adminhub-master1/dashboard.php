<?php
session_start();

if( !isset($_SESSION["login"])){
	header("location: login.php");
	exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">

	<title>Dashboard</title>
</head>
<body>

	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<!-- <i class='bx bxs-image'> -->
				<img src="logo_honda.png">
			<!-- </i> -->
			<span class="text">HONDA</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="dashboard.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="informasi.php">
					<i class='bx bxs-info-circle' ></i>
					<span class="text">Informasi Harga Kendaraan</span>
				</a>
			</li>
			<li>
				<a href="spesifikasi_motor.php">
					<i class='bx bxs-donate-blood' ></i>
					<span class="text">Spesifikasi Motor</span>
				</a>
			</li>
			<li>
				<a href="bandingkan_harga.php">
					<i class='bx bx-search-alt-2' ></i>
					<span class="text">Bandingkan Harga Motor</span>
				</a>
			</li>
			<li>
				<a href="chart.php">
					<i class='bx bx-chart' ></i>
					<span class="text">Chart</span>
				</a>
			</li>
			<li>
				<a href="cari_dealer.php">
					<i class='bx bxs-home-circle' ></i>
					<span class="text">Cari Dealer</span>
				</a>
			</li>
		</ul>

		<ul class="side-menu">
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="profile">
				<img src="img/people.png">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>

			<ul class="box-info">
				<li>
					<!-- <i class='bx bxs-info-square' ></i> -->
					<span class="text">
					<h3 style="text-align: start;">Tentang HONDA ASTRA MOTOR</h3><br>
						<p>PT Astra Honda Motor adalah sebuah perusahaan yang bergerak di bidang manufaktur, perakitan dan distributor sepeda motor merek dan tipe Honda. Dan perusahaan ini merupakan satu-satunya di Indonesia yang memiliki hak sebagai Agen Tunggal Pemegang Merek sepeda motor Honda</p>
					</span>
				</li>
				<li>
					<!-- <i class='bx bxs-group' ></i> -->
					<span class="text">
						<h3 style="text-align: start;">Kenapa Aplikasi ini dibutuhkan?</h3><br>
						<p>Karena aplikasi ini dapat menampilkan data-data harga kendaraan motor, spesifikasi, perbandingan harga kendaraan, dan juga dealer di kota-kota yang ada di Indonesia. </p>
					</span>
				</li>
			</ul>


			<div class="table-data">
				<div class="order">
					<div class="head">
				    </div>
					<section class="products" id="products">
					<div class="box">
	<div class="content">
		<div class="info"> 
		<img src="iklan honda.webp"> 			
		</div>

		<div class="content">
		<div class="info"> 
		<img src="iklan honda2.webp"> 			
		</div>
   

</section>

			
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>
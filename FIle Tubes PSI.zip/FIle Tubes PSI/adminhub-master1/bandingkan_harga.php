<?php
include 'db.php';
session_start();

if( !isset($_SESSION["login"])){
	header("location: login.php");
	exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">

	<title>Dashboard</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<!-- <i class='bx bxs-image'> -->
				<img src="logo_honda.png">
			<!-- </i> -->
			<span class="text">HONDA</span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="dashboard.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
            <li>
				<a href="informasi.php">
					<i class='bx bxs-info-circle' ></i>
					<span class="text">Informasi Harga Kendaraan</span>
				</a>
			</li>
			<li>
				<a href="spesifikasi_motor.php">
					<i class='bx bxs-donate-blood' ></i>
					<span class="text">Spesifikasi Motor</span>
				</a>
			</li>
            <li class="active">
				<a href="bandingkan_harga.php">
					<i class='bx bx-search-alt-2' ></i>
					<span class="text">Bandingkan Harga Motor</span>
				</a>
			</li>
			<li>
				<a href="chart.php">
					<i class='bx bx-chart' ></i>
					<span class="text">Chart</span>
				</a>
			</li>
			 <li>
				<a href="cari_dealer.php">
					<i class='bx bxs-home-circle' ></i>
					<span class="text">Cari Dealer</span>
				</a>
			</li>
		</ul>

		<ul class="side-menu">
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="profile">
				<img src="img/people.png">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="card">
				<div class="card-head text-center">
					<h2 class="mx-auto">Bandingkan Harga Kendaraan Antar Daerah</h2>
				</div>


				<!-- aa -->

<div class="card-body">

<script>
    // Fungsi untuk menangani perubahan select option dan mengirimkan form
    function submitForm() {
        document.getElementById("formFilter").submit();
    }
</script>

<div class="card-body">
    <form id="formFilter" method="post" action="">
        <div class="row filter-product">
            <select name="kota_a" id="kota-a" class="form-select" style="margin-left: 0;" onchange="submitForm()">
                <option value="" <?php if (isset($_POST['kota_a']) && $_POST['kota_a'] === "") echo 'selected'; ?>>Pilih Kota</option>
                <option value="Yogyakarta" <?php if (isset($_POST['kota_a']) && $_POST['kota_a'] === "Yogyakarta") echo 'selected'; ?>>Yogyakarta</option>
                <option value="Semarang" <?php if (isset($_POST['kota_a']) && $_POST['kota_a'] === "Semarang") echo 'selected'; ?>>Semarang</option>
                <option value="Surabaya" <?php if (isset($_POST['kota_a']) && $_POST['kota_a'] === "Surabaya") echo 'selected'; ?>>Surabaya</option>
            </select>
            <select name="kendaraan" id="kendaraan" class="form-select" onchange="submitForm()">
                <option value="" <?php if (isset($_POST['kendaraan']) && $_POST['kendaraan'] === "") echo 'selected'; ?>>Pilih Kendaraan</option>
                <option value="Beat" <?php if (isset($_POST['kendaraan']) && $_POST['kendaraan'] === "Beat") echo 'selected'; ?>>Beat</option>
                <option value="Vario" <?php if (isset($_POST['kendaraan']) && $_POST['kendaraan'] === "Vario") echo 'selected'; ?>>Vario</option>
                <option value="Scoopy" <?php if (isset($_POST['kendaraan']) && $_POST['kendaraan'] === "Scoopy") echo 'selected'; ?>>Scoopy</option>
            </select>
            <select name="kota_b" id="kota-b" class="form-select" style="margin-left: 0;" onchange="submitForm()">
                <option value="" <?php if (isset($_POST['kota_b']) && $_POST['kota_b'] === "") echo 'selected'; ?>>Pilih Kota</option>
                <option value="Yogyakarta" <?php if (isset($_POST['kota_b']) && $_POST['kota_b'] === "Yogyakarta") echo 'selected'; ?>>Yogyakarta</option>
                <option value="Semarang" <?php if (isset($_POST['kota_b']) && $_POST['kota_b'] === "Semarang") echo 'selected'; ?>>Semarang</option>
                <option value="Surabaya" <?php if (isset($_POST['kota_b']) && $_POST['kota_b'] === "Surabaya") echo 'selected'; ?>>Surabaya</option>
            </select>
        </div>
    </form>

	<div class="row product-container">
        <div class="product-item-start">
            <div class="product-title">Tabel Kiri (Kota A)</div>
            <div class="product-body">
                <table class="product-table" style="width: 100%;">
                    <thead>
                        <tr>
                            <th>Tipe</th>
                            <th>Harga</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Query SQL untuk mengambil data motor_nama dan harga untuk Tabel Kiri (Kota A)
                        $sqlKotaA = "SELECT motor_nama, harga FROM motor 
                                    INNER JOIN spesifikasi_motor ON motor.motor_id = spesifikasi_motor.motor_id";
                        
                        // Menambahkan kondisi WHERE sesuai dengan pilihan kota dan kendaraan untuk Tabel Kiri (Kota A)
                        $conditionsKotaA = array();
						if (isset($_POST['kota_a']) && $_POST['kota_a'] !== "") {
							$kotaA = $_POST['kota_a'];
							$conditionsKotaA[] = "dealer_id IN (SELECT dealer_id FROM dealer WHERE kota = '$kotaA')";
						}
						if (isset($_POST['kendaraan']) && $_POST['kendaraan'] !== "") {
							$kendaraan = $_POST['kendaraan'];
							$conditionsKotaA[] = "motor_nama LIKE '$kendaraan%'";
						}

						// Menambahkan kondisi WHERE jika ada untuk Tabel Kiri (Kota A)
						if (!empty($conditionsKotaA)) {
							$sqlKotaA .= " WHERE " . implode(" AND ", $conditionsKotaA);
						}

                        $resultKotaA = $conn->query($sqlKotaA);
						if ($resultKotaA->num_rows > 0) {
                            // Tampilkan data
                            while ($rowKotaA = $resultKotaA->fetch_assoc()) {
                                echo '<tr>';
                                echo '<td>'.$rowKotaA['motor_nama'].'</td>';
                                echo '<td>'.$rowKotaA['harga'].'</td>';
                                echo '</tr>';
                            }
                        } else {
                            // Tampilkan pesan jika tidak ada data yang sesuai
                            echo '<tr><td colspan="2">Tidak ada data yang sesuai.</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="product-item-end">
            <div class="product-title">Tabel Kanan (Kota B)</div>
            <div class="product-body">
                <table class="product-table" style="width: 100%;">
                    <thead>
                        <tr>
                            <th>Tipe</th>
                            <th>Harga</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Query SQL untuk mengambil data motor_nama dan harga untuk Tabel Kanan (Kota B)
                        $sqlKotaB = "SELECT motor_nama, harga FROM motor 
                                    INNER JOIN spesifikasi_motor ON motor.motor_id = spesifikasi_motor.motor_id";
                        
                        // Menambahkan kondisi WHERE sesuai dengan pilihan kota dan kendaraan untuk Tabel Kanan (Kota B)
                        $conditionsKotaB = array();
						if (isset($_POST['kota_b']) && $_POST['kota_b'] !== "") {
							$kotaB = $_POST['kota_b'];
							$conditionsKotaB[] = "dealer_id IN (SELECT dealer_id FROM dealer WHERE kota = '$kotaB')";
						}
						if (isset($_POST['kendaraan']) && $_POST['kendaraan'] !== "") {
							$kendaraan = $_POST['kendaraan'];
							$conditionsKotaB[] = "motor_nama LIKE '$kendaraan%'";
						}

						// Menambahkan kondisi WHERE jika ada untuk Tabel Kanan (Kota B)
						if (!empty($conditionsKotaB)) {
							$sqlKotaB .= " WHERE " . implode(" AND ", $conditionsKotaB);
						}


                        $resultKotaB = $conn->query($sqlKotaB);

                        // Periksa apakah ada hasil data untuk Tabel Kanan (Kota B)
                        if ($resultKotaB->num_rows > 0) {
                            // Tampilkan data
                            while ($rowKotaB = $resultKotaB->fetch_assoc()) {
                                echo '<tr>';
                                echo '<td>'.$rowKotaB['motor_nama'].'</td>';
                                echo '<td>'.$rowKotaB['harga'].'</td>';
                                echo '</tr>';
                            }
                        } else {
                            // Tampilkan pesan jika tidak ada data yang sesuai
                            echo '<tr><td colspan="2">Tidak ada data yang sesuai.</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>




















</div>




				<!-- aa -->
				
				

			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>
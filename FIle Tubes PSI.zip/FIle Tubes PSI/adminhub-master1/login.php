<?php
session_start();
if( isset($_SESSION["login"])){
	header("location: dashboard.php");
	exit;
}

require 'functions.php';

if(isset($_POST["login"])){
	$username = $_POST["username"];
	$password = $_POST["password"];

	$result = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
	
    if( mysqli_num_rows($result) === 1 ) {

		$row = mysqli_fetch_assoc($result);
		if( password_verify($password, $row["password"])){

			$_SESSION["login"] = true;

			header("Location: dashboard.php");
			exit;

		

		}
	}
	$error = true;
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/stylelogin.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<?php if (isset($error)) : ?>
		<Script>alert('username / password anda salah!')</Script>;
		<?php endif; ?> 
	<img class="wave" src="wave redd.png">
	<img class="wave2" src="wave reddd.png">
	
	<div class="container">
		

		<div class="login-content">

			<div class="img">
				<h3 class="title">Honda Astra Motor</h3>
				<img src="logo_honda.png">
			</div>
			
			<form action="" method="post">
				<!-- <img src="img/avatar.svg"> -->
				<h3 class="title">Selamat Datang Di Honda Astra Motor! </h3><br>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>

           		   <div class="div">
           		   		<h5>Username</h5>
           		   		<input type="text" class="input" name="username" id="username" required>
           		   </div>
           		</div>

           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Password</h5>
           		    	<input type="password" class="input" name="password" id="password" required>
            	   </div>
            	</div>
				
				<div class="member">Belum punya akun?
					<a href="buat_akun.php">Buat Akun</a>
				</div>

            	<input type="submit" name="login" class="btn" value="Login">
				
			</form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>
